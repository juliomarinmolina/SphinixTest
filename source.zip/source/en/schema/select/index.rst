.. _en/schema/select/index

=============================
Select objects from workspace
=============================

.. toctree::
   :maxdepth: 2

   select_object
   select_multiple_objects
   select_all
   select_none
   select_invert