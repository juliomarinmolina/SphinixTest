.. _en/schema/index

======
Schema
======

.. toctree::
   :maxdepth: 2

   what_is
   element/index
   conductor/index
   text/index
   table
   basics/index
   picture
   select/index
   copy
   cut
   paste
   multiple_paste
   delete
   rotate
   layers
   search
   replace/index