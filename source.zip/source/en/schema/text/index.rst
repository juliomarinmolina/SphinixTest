.. _en/schema/text/index

=======================
Working with text field
=======================

.. toctree::
   :maxdepth: 2

   text_insert
   text_edit
   text_editor
   text_move
   text_rotate
   link_url