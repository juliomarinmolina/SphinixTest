.. _en/schema/what_is

==================
What is a schema?
==================
