.. _en/element/properties/element_text

==================
Texts from element
==================


.. figure:: graphics/qet_element_properties_text.png
   :align: center

   Figure: QElectroTech text element properties
