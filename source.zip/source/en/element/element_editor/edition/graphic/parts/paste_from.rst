.. _en/element/element_editor/edition/graphic/parts//paste_from

==========
Paste from
==========
