.. _en/element/element_editor/edition/graphic/parts/select/index

===========================
Select parts from workspace
===========================

.. toctree::
   :maxdepth: 2

   select_part
   select_multiple_parts
   select_all
   select_none
   select_invert