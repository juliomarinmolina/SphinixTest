.. _en/element/element_editor/edition/graphic/index

==================
Graphic definition
==================

.. toctree::
   :maxdepth: 2

   parts/index
   layers
   element_size