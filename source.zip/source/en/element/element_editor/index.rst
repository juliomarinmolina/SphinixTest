.. _en/element/element_editor/index

==============
Element editor
==============

.. toctree::
   :maxdepth: 2

   what_is
   interface/index
   editor_open
   element_save
   editor_quit
   edition/index