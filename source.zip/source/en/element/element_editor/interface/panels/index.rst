.. _en/element/element_editor/interface/panles/index

=====================
Element editor panels
=====================

.. toctree::
   :maxdepth: 2

   parts
   selection_properties
   undo