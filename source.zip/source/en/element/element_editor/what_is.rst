.. _en/element/element_editor/what_is

===========================
What is the element editor?
===========================

QElectroTech allows the user costumizing elemets from the user collection. The element editor is the editor 
provided by QElectroTech to modify existing element from the user collection and create new elements to 
the collection. 

The element editor is displayed as a PopUP window from QElectroTech and looks like the picture bellow.

.. figure:: graphics/qet_elementeditor.png
   :align: center

   Figure: QElectroTech element editor