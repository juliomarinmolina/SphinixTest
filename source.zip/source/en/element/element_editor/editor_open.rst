.. _en/element/element_editor/editor_open

====================
Open element editor
====================

QElectroTech allows displaying the element editor PopUP window by creating a new element or by editing an 
existing element.

Open element editor by creating a new element
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    1. Refers to the section **link** for opening the element editor by creating a new element from the project panel.

Open element editor by editing an element
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    1. Refers to the section **Link** for opening the element editor by editing an element from collection oanle.
    2. Refers to section **Link** for opening the element editor by editing an element from the workspace.