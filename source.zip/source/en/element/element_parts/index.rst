.. _en/element/element_parts/index

====================
Element parts
====================

.. toctree::
   :maxdepth: 2

   line
   rectangle
   ellipse
   polygon
   text
   arc
   terminal
   dynamic_text