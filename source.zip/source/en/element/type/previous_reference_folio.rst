.. _en/element/type/previous_reference_folio

========================
Previous reference folio
========================

Element which link the begining of a `conductor`_ with the end of the `conductor`_ represented at 
previous, following or same `folio`_.

.. figure:: graphics/qet_element_reference_folio.png
   :align: center

   Figure: QElectroTech previous reference folio

For previous referencing folio element exist two type of variables, the general variables that are 
common for all type of `elements`_ and the specific variables for this type of `element`_.

QElectroTech does not allow defining variable values for this type of `element`_. QElectroTech does 
also not allows defining new variables. QElectroTech allows only displaying the specific variables 
at `dynamic texts`_. 

General variables 

    * **% {F}**: Label from the `folio`_ where the `element`_ can be found.
    * **% {f}**: Number from the `folio`_ where the `element`_ can be found.
    * **% {M}**: Plant variable from the `folio`_ where the `element`_ can be found.
    * **% {LM}**: Location variable of the `folio`_ where the `element`_ can be found.
    * **% {l}**: Folio line number from the `workspace`_ where the `element`_ can be found.
    * **% {c}**: Folio column number from the `workspace`_ where the `element`_ can be found.
    * **% {id}**: Folio position in the `project`_ (Schema number).

Specific variables

    * **Function**: Function property from the `conductor`_ connected to the `element terminal`_.
    * **Label**: Internal variable which defines the position of the linked `reference folio following`_ element.
    * **Voltage/Protocol**: Voltage/Protocol property from the `conductor`_ connected to the `element terminal`_.

.. note:: 

    The **Label** property can be defined as a formula by the user at `New folio`_ section from 
    `project properties`_. By default the formula is ``%id-%l%c``, variables took from 
    `reference folio following`_ linked element.

    For more information about how to define the **Label** formula, please refers to 
    `folio referencing project properties`_.

.. _conductor: ../../../en/conductor/index.html
.. _folio: ../../../en/folio/index.html
.. _element: ../../../en/element/index.html
.. _elements: ../../../en/element/index.html
.. _project: ../../../en/project/index.html
.. _workspace: ../../../en/interface/workspace.html
.. _element terminal: ../../../en/element/element_parts/terminal.html
.. _dynamic texts: ../../../en/element/element_parts/dynamic_text.html
.. _reference folio following: ../../../en/element/type/reference_folio_following.html
.. _project properties: ../../../en/project/properties/index.html
.. _New folio: ../../../en/project/properties/new_folio/index.html
.. _folio referencing project properties: ../../../en/project/properties/new_folio/folio_referencing.html