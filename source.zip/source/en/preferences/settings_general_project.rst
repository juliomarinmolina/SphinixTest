.. _en/preferences/settings_general_project

=================
Project settings
=================

.. figure:: graphics/qet_general_project_settings.png
    :align: center

    Figure: QElectroTech general project settings