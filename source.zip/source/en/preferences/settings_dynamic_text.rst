.. _en/preferences/settings_dynamic_text

=======================
Dynamic text settings
=======================

.. figure:: graphics/qet_dynamic_texts_settings.png
    :align: center

    Figure: QElectroTech dynamic texts settings