.. _en/preferences/index

===========
Preferences
===========

.. toctree::
   :maxdepth: 2

   display_settings
   appearance
   settings_general_project
   settings_element
   language
   settings_dynamic_text
   new_project/index
   settings_export
   settings_printing