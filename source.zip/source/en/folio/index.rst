.. _en/folio/index

=====
Folio
=====

.. toctree::
   :maxdepth: 2

   what_is
   type/index
   add_folio
   delete_folio
   properties/index
   title_block/index