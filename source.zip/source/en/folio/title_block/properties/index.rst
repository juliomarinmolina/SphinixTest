.. _en/folio/title_block/properties/index

======================
Properties Title Block
======================

.. toctree::
   :maxdepth: 2

   parent_collection
   extra_info