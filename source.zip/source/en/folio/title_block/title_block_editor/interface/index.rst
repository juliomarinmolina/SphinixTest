.. _en/folio/title_block/title_block_editor/interface/index

============================
Interface title block editor
============================

.. toctree::
   :maxdepth: 2

   elements_interface
   menu_bar
   workspace
   toolbars
   panels