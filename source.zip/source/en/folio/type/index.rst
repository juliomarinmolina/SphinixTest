.. _en/folio/type/index

=============
Type of folio
=============

.. toctree::
   :maxdepth: 2

   single_line_diagram
   multiline_diagram