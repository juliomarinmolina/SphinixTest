.. _en/content

===================
QElectroTech Manual
===================


.. toctree::
   :maxdepth: 2

   basics/index
   interface/index
   preferences/index
   project/index
   folio/index
   element/index
   conductor/index
   schema/index
   drawing/index
   reports/index
   export&print/index
   annex/index