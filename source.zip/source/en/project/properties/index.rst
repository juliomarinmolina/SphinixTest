.. _en/project/properties/index

==================
Project properties
==================

.. toctree::
   :maxdepth: 2

   display
   general_prop
   new_folio/index
   numbering_prop