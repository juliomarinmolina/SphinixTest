.. _en/project/properties/new_folio/index

====================
New folio properties
====================

.. toctree::
   :maxdepth: 2

   folio
   conductor
   folio_referencing
   cross_references