.. _en/reports/component_list

====================
Component list
====================
