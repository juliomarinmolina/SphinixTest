.. _en/interface/index

=========
Interface
=========

.. toctree::
   :maxdepth: 2

   elements
   menu_bar
   workspace
   toolbars
   panels/index
   help_bar
   projects_tab
   folios_tab
   search_menu
   customize/index