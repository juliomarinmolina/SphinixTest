24x16 Flag icons - http://www.strangeplanet.fr

These icons are public domain, and as such are free for any use (attribution appreciated but not required).

Note that these flags are mostly named using the ISO3166-1 alpha-2 country codes where appropriate.

If you redistribute the pack please let the readme file into.

If you find these icons useful, share-them!

Contact: webmaster@strangeplanet.fr