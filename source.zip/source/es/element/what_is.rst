.. _es/element/what_is

===================
What is an element?
===================

One element is an object which function is to reduce the engineering work. Working with elements 
reduce the time and work necessary for the creation of schemas, Bill Of Materials (BOM) and many 
other types of reports such terminal lists, I/O lists, etc.  

As can be understood from the previous paragraph, a QElectroTech element is something more that a 
graphic symbol. The information provided by an element is the following:

    1. Graphical representation information, symbol displayed at the schema.
    2. Element data such element position in the poject, article number, manufacturer, supplier, link to any other element from the project, etc.

.. figure:: graphics/qet_element.png
   :align: center

   Figure: QElectroTech thermal circuit breaker element

At QElectroTech, all element can be clasified at different element families. The graphical 
representation information characteristics are the same for all families. The element database 
fields posibilities and the possible interloking options are the characteristics which make 
differences between element families.

The element families from QElectroTech are the following:

    * `Simple <../../es/element/type/elementsimple.html>`_
    * `Master <../../es/element/type/elementmaster.html>`_ 
    * `Slave <../../es/element/type/elementslave.html>`_
    * `Reference folio following <../../es/element/type/referencefoliofollowing.html>`_
    * `Previous reference folio <../../es/element/type/previousreferencefolio.html>`_
    * `Terminal block <../../es/element/type/terminalblock.html>`_
