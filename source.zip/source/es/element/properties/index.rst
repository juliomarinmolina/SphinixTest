.. _es/element/properties/index

==================
Element properties
==================

.. toctree::
   :maxdepth: 2

   element_properties_display
   element_general
   element_text
   element_information
   element_author
   element_numbering
