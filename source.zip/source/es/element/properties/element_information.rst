.. _es/element/properties/element_information

===================
Element information 
===================

.. figure:: graphics/qet_element_properties_information.png
   :align: center

   Figure: QElectroTech information element properties
