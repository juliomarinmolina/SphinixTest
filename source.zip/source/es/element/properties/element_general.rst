.. _es/element/properties/element_general

==========================
General properties element
==========================

.. figure:: graphics/qet_element_properties_general.png
   :align: center

   Figure: QElectroTech general element properties
