.. _es/element/element_editor/interface/index

========================
Interface element editor
========================

.. toctree::
   :maxdepth: 2

   elements_interface
   menu_bar
   workspace
   toolbars
   panels/index
