.. _es/element/element_editor/edition/graphic/parts//paste_from

==========
Paste from
==========
