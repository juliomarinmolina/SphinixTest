.. _es/element/element_editor/edition/graphic/parts/add

===================
Add part to element
===================

Adding parts to the `Drawing area`_ from the `element editor`_ can only be done from the `parts toolbar`_.

.. note::

   If the `toolbar`_ is not displayed, it can be displayed from **Settings > Display > Parts**.

For more information about how to add each type of part (`Line`_, `Rectangle`_, `Ellipse`_, `Arc`_, 
`Polygon`_, `Terminal`_, `text`_ and `dynamic text field`_), please refers to the `Element part`_ 
section.

.. _toolbar: ../../../../../../es/element/element_editor/interface/toolbars.html
.. _parts toolbar: ../../../../../../es/element/element_editor/interface/toolbars.html
.. _element editor: ../../../../../../es/element/element_editor/index.html
.. _Drawing area: ../../../../../../es/element/element_editor/interface/workspace.html
.. _Line: ../../../../../../es/element/element_parts/line.html
.. _Rectangle: ../../../../../../es/element/element_parts/rectangle.html
.. _Ellipse: ../../../../../../es/element/element_parts/ellipse.html
.. _Arc: ../../../../../../es/element/element_parts/arc.html
.. _Polygon: ../../../../../../es/element/element_parts/polygon.html
.. _Terminal: ../../../../../../es/element/element_parts/terminal.html
.. _text: ../../../../../../es/element/element_parts/text.html
.. _dynamic text field: ../../../../../../es/element/element_parts/dynamic_text.html
.. _Element part: ../../../../../../es/element/element_parts/index.html
