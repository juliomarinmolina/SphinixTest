.. _es/element/element_editor/edition/properties/index

=============================
Element properties definition
=============================

.. toctree::
   :maxdepth: 2

   edit_element_name
   define_element_author
   edit_element_prop
