.. _es/element/element_editor/edition/index

=======================
Create or edit elements
=======================

.. toctree::
   :maxdepth: 2

   graphic/index
   properties/index
