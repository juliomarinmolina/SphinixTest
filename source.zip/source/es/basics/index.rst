.. _es/basics/index

======
Basics
======

.. toctree::
   :maxdepth: 2

   start_linux
   start_windows
   start_mac
   help
   quit
