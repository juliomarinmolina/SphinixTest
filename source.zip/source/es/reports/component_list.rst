.. _es/reports/component_list

====================
Component list
====================
