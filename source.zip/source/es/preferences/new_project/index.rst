.. _es/preferences/new_project/index

====================
New project settings
====================

.. toctree::
   :maxdepth: 2

   folio_settings
   conductor_settings
   folio_referencings_settings
   cross_references_settings
