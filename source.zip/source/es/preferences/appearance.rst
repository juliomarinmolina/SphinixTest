.. _es/preferences/appearance

=======================
QElectroTech appearance
=======================

.. figure:: graphics/qet_appearance_settings.png
   :align: center

   Figure: QElectroTech appearance settings
