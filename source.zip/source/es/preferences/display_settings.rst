.. _es/preferences/display_settings

=================
Display settings
=================

QElectroTech allows the user customizing many settings: `language`_, `appearance`_, `export`_ and `printing`_ 
settings, pre-define `new project`_ settings, `element`_ collection paths, etc.

To display the QElectroTech settings:

    1. Select **Settings > Configure QElectroTech** menu item to display QElectroTech settings PopUP window.

        .. figure:: graphics/qet_settings_menu.png
            :align: center

            Figure: QElectroTech Settings menu

.. _language: ../../es/preferences/language.html
.. _appearance: ../../es/preferences/appearance.html
.. _export: ../../es/preferences/settings_export.html
.. _printing: ../../es/preferences/settings_printing.html
.. _new project: ../../es/preferences/settings_project.html
.. _element: ../../es/preferences/settings_element.html
