.. _es/interface/panels/index

======
Panels
======

.. toctree::
   :maxdepth: 2

   projects_panel
   collections_panel
   selection_properties_panel
   autonumbering_panel
   undo_panel
