.. _es/interface/workspace

=========
Workspace
=========

The workspace, also named grafical editor, is the area where the schematics and reports (Index table, 
component list, symbol glosary, etc.) are created. 

At the figure bellow, the appearance from QElectroTech workspace can be found. 

.. figure:: graphics/qet_workspace.png
   :align: center

   Figure: QElectroTech Workspace
