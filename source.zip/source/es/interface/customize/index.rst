.. _es/interface/customize/index

=================
GUI costumization
=================

.. toctree::
   :maxdepth: 2

   toolbarsposition
   panelsposition
   projectdisplay
   fullscreen
