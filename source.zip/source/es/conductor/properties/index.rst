.. _es/conductor/properties/index

====================
Conductor properties
====================

.. toctree::
   :maxdepth: 2

   display_conductor_properties
   conductor_type
   conductor_appearance
   conductor_numbering
