.. _es/project/index

=======
Project
=======

.. toctree::
   :maxdepth: 2

   what_is
   new_project
   open_project
   save_project
   close_project
   clean_project
   properties/index
