.. _es/folio/properties/index

================
Folio properties
================

.. toctree::
   :maxdepth: 2

   display
   folio_size
   folio_title_block
   folio_type
   folio_appearance
