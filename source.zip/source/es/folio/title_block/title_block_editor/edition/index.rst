.. _es/folio/title_block/title_block_editor/edition/index

==========================
Create or edit title block
==========================

.. toctree::
   :maxdepth: 2

   row_add
   row_height
   row_delete
   column_add
   column_width
   column_delete
   logo
   cells_value
   cells_merge
   cells_split
   define_extra_info
