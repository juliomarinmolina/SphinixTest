.. _es/folio/title_block/title_block_editor/edition/row_delete

===========================
Delete row from title block
===========================

QElectroTech `Title Block editor`_ allows only deleting `rows`_ of the `Title Block`_ from the 
`Drawing area`_.

    1. Right click on the head from the `row`_ which should be deleted.
    2. Click the option **Delete this row** to delete the selected `row`_.

.. figure:: graphics/qet_titleblock_column_action.png
   :align: center

   Figure: QElectroTech title block editor, drawing area

.. _Title Block editor: ../../../../../es/folio/title_block/title_block_editor/index.html
.. _Title Block: ../../../../../es/folio/title_block/index.html
.. _row: ../../../../../es/folio/title_block/elements/row.html
.. _rows: ../../../../../es/folio/title_block/elements/row.html
.. _Drawing area: ../../../../../es/folio/title_block/title_block_editor/interface/workspace.html 
