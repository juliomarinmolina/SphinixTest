.. _es/folio/title_block/title_block_editor/editor_open

=======================
Open title block editor
=======================

QElectroTech allows displaying the title block editor PopUP window by creating a new title block or by editing an 
existing title block template.

Open title block editor by creating a new title block
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    1. Refers to the section **link** for opening the title block editor by creating a new title block from the project panel.

Open title block editor by editing an title block
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    1. Refers to the section **Link** for opening the title block editor by editing an title block from collection oanle.
    2. Refers to section **Link** for opening the title block editor by editing an title block from the workspace.
